import { useState } from "react";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { motion } from "framer-motion";
import { CalendarIcon, Loader2, Tag } from "lucide-react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

import { 
  useListCategories, 
  useCreateExpense,
  getListExpensesQueryKey,
  getGetMonthlySummaryQueryKey,
  getGetSummaryByCategoryQueryKey,
  getGetRecentExpensesQueryKey
} from "@workspace/api-client-react";

const formSchema = z.object({
  amount: z.coerce.number().positive("Сумма должна быть больше 0"),
  description: z.string().min(1, "Введите описание расхода"),
  categoryId: z.number().optional().nullable(),
  date: z.date({
    required_error: "Выберите дату",
  }),
});

type FormValues = z.infer<typeof formSchema>;

export default function AddExpense() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: categories, isLoading: isLoadingCategories } = useListCategories();
  const createMutation = useCreateExpense();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      amount: undefined,
      description: "",
      categoryId: null,
      date: new Date(),
    },
  });

  const onSubmit = (values: FormValues) => {
    // Format date as YYYY-MM-DD
    const formattedDate = format(values.date, 'yyyy-MM-dd');
    
    createMutation.mutate({
      data: {
        amount: values.amount,
        description: values.description,
        categoryId: values.categoryId,
        date: formattedDate
      }
    }, {
      onSuccess: () => {
        toast({
          title: "Сохранено",
          description: "Расход успешно добавлен",
        });
        
        // Invalidate queries
        queryClient.invalidateQueries({ queryKey: getListExpensesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetMonthlySummaryQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetSummaryByCategoryQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetRecentExpensesQueryKey() });
        
        setLocation("/expenses");
      },
      onError: () => {
        toast({
          variant: "destructive",
          title: "Ошибка",
          description: "Не удалось сохранить расход",
        });
      }
    });
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-xl mx-auto space-y-6"
    >
      <header>
        <h1 className="text-3xl font-serif text-foreground tracking-tight">Новая запись</h1>
        <p className="text-muted-foreground mt-1">Добавьте информацию о расходе</p>
      </header>

      <Card className="border-border shadow-sm rounded-2xl overflow-hidden">
        <CardContent className="p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              
              <div className="bg-muted/30 p-6 -mx-6 -mt-6 mb-6 border-b border-border flex justify-center">
                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem className="text-center w-full max-w-xs">
                      <FormLabel className="sr-only">Сумма</FormLabel>
                      <FormControl>
                        <div className="relative flex items-center justify-center">
                          <Input 
                            type="number" 
                            step="0.01"
                            inputMode="decimal"
                            className="text-5xl font-bold h-20 text-center bg-transparent border-none shadow-none focus-visible:ring-0 focus-visible:ring-offset-0 px-8 w-full placeholder:text-muted-foreground/30"
                            placeholder="0"
                            {...field} 
                            value={field.value || ""}
                          />
                          <span className="absolute right-4 text-2xl font-medium text-muted-foreground">₽</span>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-medium text-foreground">Описание</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Например: Продукты в Пятерочке" 
                        className="resize-none rounded-xl bg-card"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="categoryId"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel className="font-medium text-foreground mb-1">Категория</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              role="combobox"
                              className={cn(
                                "justify-between rounded-xl h-11 bg-card text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value
                                ? (
                                  <div className="flex items-center gap-2">
                                    {categories?.find(c => c.id === field.value)?.name}
                                  </div>
                                )
                                : "Выберите категорию"}
                              <Tag className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-[200px] p-2 rounded-xl" align="start">
                          <div className="space-y-1">
                            {isLoadingCategories ? (
                              <div className="p-2 text-sm text-center text-muted-foreground">Загрузка...</div>
                            ) : categories?.length === 0 ? (
                              <div className="p-2 text-sm text-center text-muted-foreground">Нет категорий</div>
                            ) : (
                              categories?.map((category) => (
                                <div
                                  key={category.id}
                                  className={cn(
                                    "flex items-center gap-2 p-2 rounded-lg cursor-pointer hover:bg-muted transition-colors",
                                    field.value === category.id && "bg-muted font-medium"
                                  )}
                                  onClick={() => {
                                    field.onChange(category.id);
                                  }}
                                >
                                  <div 
                                    className="w-3 h-3 rounded-full" 
                                    style={{ backgroundColor: category.color }}
                                  />
                                  {category.name}
                                </div>
                              ))
                            )}
                          </div>
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel className="font-medium text-foreground mb-1">Дата</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full pl-3 text-left font-normal rounded-xl h-11 bg-card",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "d MMMM yyyy", { locale: ru })
                              ) : (
                                <span>Выберите дату</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0 rounded-xl overflow-hidden" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) =>
                              date > new Date() || date < new Date("1900-01-01")
                            }
                            initialFocus
                            locale={ru}
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="pt-4 flex gap-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  className="w-full rounded-xl h-12"
                  onClick={() => setLocation("/")}
                >
                  Отмена
                </Button>
                <Button 
                  type="submit" 
                  className="w-full rounded-xl h-12"
                  disabled={createMutation.isPending}
                >
                  {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Добавить запись
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </motion.div>
  );
}
