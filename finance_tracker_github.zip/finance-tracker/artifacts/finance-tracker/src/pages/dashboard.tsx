import { useState } from "react";
import { format, subMonths, addMonths } from "date-fns";
import { ru } from "date-fns/locale";
import { motion, AnimatePresence } from "framer-motion";
import { 
  ChevronLeft, 
  ChevronRight, 
  TrendingUp, 
  TrendingDown, 
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  Tag
} from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from "recharts";
import { Link } from "wouter";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  useGetMonthlySummary, 
  useGetSummaryByCategory,
  useListExpenses,
  getGetMonthlySummaryQueryKey,
  getGetSummaryByCategoryQueryKey,
  getListExpensesQueryKey
} from "@workspace/api-client-react";
import { cn } from "@/lib/utils";

// Format currency
const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    maximumFractionDigits: 0
  }).format(amount);
};

export default function Dashboard() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const monthStr = format(currentDate, 'yyyy-MM');

  const { data: summary, isLoading: isLoadingSummary } = useGetMonthlySummary(
    { month: monthStr },
    { query: { queryKey: getGetMonthlySummaryQueryKey({ month: monthStr }) } }
  );

  const { data: categorySummary, isLoading: isLoadingCategories } = useGetSummaryByCategory(
    { month: monthStr },
    { query: { queryKey: getGetSummaryByCategoryQueryKey({ month: monthStr }) } }
  );

  const { data: recentExpenses, isLoading: isLoadingRecent } = useListExpenses(
    { month: monthStr },
    { query: { queryKey: getListExpensesQueryKey({ month: monthStr }) } }
  );

  const handlePrevMonth = () => setCurrentDate(subMonths(currentDate, 1));
  const handleNextMonth = () => setCurrentDate(addMonths(currentDate, 1));

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-serif text-foreground tracking-tight">Обзор</h1>
          <p className="text-muted-foreground mt-1">Как вы тратите свои средства</p>
        </div>
        
        <div className="flex items-center gap-2 bg-card border border-border p-1 rounded-full shadow-sm w-fit">
          <Button variant="ghost" size="icon" className="rounded-full h-8 w-8" onClick={handlePrevMonth}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="w-32 text-center font-medium capitalize select-none">
            {format(currentDate, 'LLLL yyyy', { locale: ru })}
          </div>
          <Button variant="ghost" size="icon" className="rounded-full h-8 w-8" onClick={handleNextMonth}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </header>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-primary text-primary-foreground border-none shadow-md overflow-hidden relative">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <Wallet className="w-24 h-24" />
          </div>
          <CardHeader className="pb-2">
            <CardTitle className="text-primary-foreground/80 font-medium text-sm">Всего расходов</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingSummary ? (
              <Skeleton className="h-10 w-32 bg-primary-foreground/20" />
            ) : (
              <div className="text-4xl font-bold tracking-tight">
                {formatCurrency(summary?.totalAmount || 0)}
              </div>
            )}
            <div className="mt-4 flex items-center text-sm text-primary-foreground/90 bg-black/10 w-fit px-2 py-1 rounded-md">
              <span className="font-medium">{summary?.expenseCount || 0}</span>
              <span className="ml-1 opacity-80">операций в этом месяце</span>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-muted-foreground font-medium text-sm flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-amber-500" />
              В среднем за операцию
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingSummary ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <div className="text-2xl font-semibold">
                {formatCurrency(summary?.averageExpense || 0)}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-muted-foreground font-medium text-sm flex items-center gap-2">
              <Tag className="h-4 w-4 text-emerald-500" />
              Главная категория
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingSummary ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <div className="text-xl font-medium truncate">
                {summary?.topCategory || "Нет данных"}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category Chart */}
        <Card className="shadow-sm flex flex-col">
          <CardHeader>
            <CardTitle className="text-lg">Структура расходов</CardTitle>
          </CardHeader>
          <CardContent className="flex-1 min-h-[300px] flex items-center justify-center">
            {isLoadingCategories ? (
              <div className="flex items-center justify-center h-full w-full">
                <Skeleton className="h-64 w-64 rounded-full" />
              </div>
            ) : categorySummary && categorySummary.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categorySummary}
                    cx="50%"
                    cy="50%"
                    innerRadius={70}
                    outerRadius={100}
                    paddingAngle={2}
                    dataKey="totalAmount"
                    nameKey="categoryName"
                    stroke="none"
                  >
                    {categorySummary.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.categoryColor || `hsl(var(--chart-${(index % 5) + 1}))`} />
                    ))}
                  </Pie>
                  <RechartsTooltip 
                    formatter={(value: number) => formatCurrency(value)}
                    contentStyle={{ borderRadius: '12px', border: '1px solid hsl(var(--border))', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}
                  />
                  <Legend verticalAlign="bottom" height={36} iconType="circle" />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center text-muted-foreground flex flex-col items-center">
                <PieChart className="w-16 h-16 opacity-20 mb-3" />
                <p>Нет расходов в этом месяце</p>
                <Link href="/add" className="text-primary mt-2 hover:underline text-sm font-medium">
                  Добавить расход
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Expenses */}
        <Card className="shadow-sm flex flex-col">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg">Недавние операции</CardTitle>
            <Link href="/expenses" className="text-sm text-primary hover:underline font-medium">
              Все
            </Link>
          </CardHeader>
          <CardContent className="flex-1">
            {isLoadingRecent ? (
              <div className="space-y-4">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="flex items-center gap-4">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-3 w-16" />
                    </div>
                    <Skeleton className="h-4 w-16" />
                  </div>
                ))}
              </div>
            ) : recentExpenses && recentExpenses.length > 0 ? (
              <div className="space-y-1">
                {recentExpenses.slice(0, 5).map((expense, idx) => (
                  <motion.div 
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    key={expense.id} 
                    className="flex items-center justify-between p-3 rounded-xl hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div 
                        className="w-10 h-10 rounded-full flex items-center justify-center text-white shrink-0 shadow-sm"
                        style={{ backgroundColor: expense.categoryColor || 'hsl(var(--muted))' }}
                      >
                        <Tag className="w-4 h-4" /> {/* Fallback icon, could use Lucide icon name mapping */}
                      </div>
                      <div className="min-w-0">
                        <p className="font-medium text-sm truncate">{expense.description || expense.categoryName}</p>
                        <p className="text-xs text-muted-foreground">
                          {format(new Date(expense.date), 'd MMM yyyy', { locale: ru })}
                        </p>
                      </div>
                    </div>
                    <div className="font-semibold text-sm whitespace-nowrap">
                      {formatCurrency(expense.amount)}
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 bg-muted/20 rounded-xl border border-dashed border-border/60">
                <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-3">
                  <List className="w-6 h-6" />
                </div>
                <p className="text-sm font-medium text-foreground">Пока пусто</p>
                <p className="text-xs text-muted-foreground mt-1 mb-4">Начните вести учет своих финансов</p>
                <Link href="/add">
                  <Button size="sm" className="rounded-full shadow-sm">
                    <PlusCircle className="w-4 h-4 mr-2" />
                    Новая запись
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </motion.div>
  );
}

// Minimal icons import fallback since we don't have dynamic icon rendering easily available
import { List, PlusCircle } from "lucide-react";
