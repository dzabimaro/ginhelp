import { useState } from "react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { motion, AnimatePresence } from "framer-motion";
import { CalendarIcon, Plus, Search, Tag, Trash2, Filter, X } from "lucide-react";
import { Link } from "wouter";

import { 
  useListExpenses,
  useDeleteExpense,
  useListCategories,
  getListExpensesQueryKey,
  getGetMonthlySummaryQueryKey,
  getGetSummaryByCategoryQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    maximumFractionDigits: 0
  }).format(amount);
};

export default function Expenses() {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: expenses, isLoading } = useListExpenses(
    { categoryId: selectedCategory || undefined },
    { query: { queryKey: getListExpensesQueryKey({ categoryId: selectedCategory || undefined }) } }
  );

  const { data: categories } = useListCategories();

  const deleteMutation = useDeleteExpense();

  const handleDelete = (id: number) => {
    deleteMutation.mutate({ id }, {
      onSuccess: () => {
        toast({
          title: "Удалено",
          description: "Запись успешно удалена",
        });
        queryClient.invalidateQueries({ queryKey: getListExpensesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetMonthlySummaryQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetSummaryByCategoryQueryKey() });
      }
    });
  };

  const filteredExpenses = expenses?.filter(e => 
    (e.description?.toLowerCase() || "").includes(search.toLowerCase()) ||
    (e.categoryName?.toLowerCase() || "").includes(search.toLowerCase()) ||
    e.amount.toString().includes(search)
  ) || [];

  // Group by date
  const groupedExpenses = filteredExpenses.reduce((acc, expense) => {
    const date = expense.date.split('T')[0];
    if (!acc[date]) acc[date] = [];
    acc[date].push(expense);
    return acc;
  }, {} as Record<string, typeof expenses>);

  const sortedDates = Object.keys(groupedExpenses).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-serif text-foreground tracking-tight">Операции</h1>
          <p className="text-muted-foreground mt-1">История всех ваших расходов</p>
        </div>
        
        <Link href="/add">
          <Button className="rounded-full shadow-sm gap-2">
            <Plus className="w-4 h-4" />
            Добавить расход
          </Button>
        </Link>
      </header>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Поиск по описанию или сумме..." 
            className="pl-9 bg-card border-border rounded-xl"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="rounded-xl border-border bg-card gap-2 sm:w-auto w-full">
              <Filter className="h-4 w-4" />
              {selectedCategory 
                ? categories?.find(c => c.id === selectedCategory)?.name || "Фильтр"
                : "Все категории"
              }
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56 rounded-xl">
            <DropdownMenuLabel>Фильтр по категории</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem 
              onClick={() => setSelectedCategory(null)}
              className="flex items-center justify-between cursor-pointer"
            >
              Все категории
              {!selectedCategory && <span className="w-2 h-2 rounded-full bg-primary" />}
            </DropdownMenuItem>
            {categories?.map(category => (
              <DropdownMenuItem 
                key={category.id} 
                onClick={() => setSelectedCategory(category.id)}
                className="flex items-center justify-between cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: category.color }}
                  />
                  {category.name}
                </div>
                {selectedCategory === category.id && <span className="w-2 h-2 rounded-full bg-primary" />}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {selectedCategory && (
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-xl"
            onClick={() => setSelectedCategory(null)}
            title="Сбросить фильтр"
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      <div className="space-y-6 pb-12">
        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-8 w-32 mb-4" />
            <Card className="p-4"><Skeleton className="h-12 w-full" /></Card>
            <Card className="p-4"><Skeleton className="h-12 w-full" /></Card>
          </div>
        ) : sortedDates.length > 0 ? (
          <AnimatePresence mode="popLayout">
            {sortedDates.map((date) => (
              <motion.div 
                key={date}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="space-y-3"
              >
                <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2 sticky top-16 md:top-0 bg-background/80 backdrop-blur-sm py-2 z-10">
                  <CalendarIcon className="w-4 h-4" />
                  {format(new Date(date), 'd MMMM yyyy', { locale: ru })}
                </h3>
                
                <div className="space-y-2">
                  {groupedExpenses[date].map(expense => (
                    <Card key={expense.id} className="overflow-hidden border-border/50 shadow-sm hover:shadow-md transition-shadow group">
                      <div className="p-4 flex items-center justify-between gap-4">
                        <div className="flex items-center gap-4 flex-1 min-w-0">
                          <div 
                            className="w-12 h-12 rounded-xl flex items-center justify-center text-white shrink-0 shadow-sm"
                            style={{ backgroundColor: expense.categoryColor || 'hsl(var(--muted))' }}
                          >
                            <Tag className="w-5 h-5" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className="font-medium text-base text-foreground truncate">
                              {expense.description || "Без описания"}
                            </p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant="secondary" className="bg-secondary/50 hover:bg-secondary/50 text-xs font-normal border-none">
                                {expense.categoryName || "Без категории"}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-4">
                          <div className="font-semibold text-lg whitespace-nowrap">
                            {formatCurrency(expense.amount)}
                          </div>
                          
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-full">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent className="rounded-2xl">
                              <AlertDialogHeader>
                                <AlertDialogTitle>Удалить запись?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Это действие нельзя отменить. Запись будет удалена из вашей истории и статистики.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel className="rounded-xl">Отмена</AlertDialogCancel>
                                <AlertDialogAction 
                                  className="rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                  onClick={() => handleDelete(expense.id)}
                                >
                                  Удалить
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        ) : (
          <div className="text-center py-20 bg-card rounded-2xl border border-dashed border-border/60">
            <div className="w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-muted-foreground/50" />
            </div>
            <h3 className="text-lg font-medium">Ничего не найдено</h3>
            <p className="text-muted-foreground mt-2 max-w-sm mx-auto">
              По вашему запросу не найдено ни одной записи. Попробуйте изменить параметры поиска.
            </p>
            {(search || selectedCategory) && (
              <Button 
                variant="outline" 
                className="mt-6 rounded-xl"
                onClick={() => {
                  setSearch("");
                  setSelectedCategory(null);
                }}
              >
                Сбросить фильтры
              </Button>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}
