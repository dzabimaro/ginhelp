import { Router, type IRouter } from "express";
import { db, expensesTable, categoriesTable } from "@workspace/db";
import { eq, sql, desc } from "drizzle-orm";
import {
  GetMonthlySummaryQueryParams,
  GetSummaryByCategoryQueryParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/summary/monthly", async (req, res): Promise<void> => {
  const query = GetMonthlySummaryQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const monthStr = query.data.month ?? new Date().toISOString().slice(0, 7);
  const [year, month] = monthStr.split("-").map(Number);
  const start = new Date(year, month - 1, 1);
  const end = new Date(year, month, 1);

  const [result] = await db
    .select({
      totalAmount: sql<string>`coalesce(sum(${expensesTable.amount}), 0)`,
      expenseCount: sql<number>`count(*)::int`,
    })
    .from(expensesTable)
    .where(sql`${expensesTable.date} >= ${start.toISOString()} AND ${expensesTable.date} < ${end.toISOString()}`);

  const totalAmount = parseFloat(result?.totalAmount ?? "0");
  const expenseCount = result?.expenseCount ?? 0;
  const averageExpense = expenseCount > 0 ? totalAmount / expenseCount : 0;

  const topCatResult = await db
    .select({
      name: categoriesTable.name,
      total: sql<string>`sum(${expensesTable.amount})`,
    })
    .from(expensesTable)
    .leftJoin(categoriesTable, eq(expensesTable.categoryId, categoriesTable.id))
    .where(sql`${expensesTable.date} >= ${start.toISOString()} AND ${expensesTable.date} < ${end.toISOString()}`)
    .groupBy(categoriesTable.name)
    .orderBy(sql`sum(${expensesTable.amount}) desc`)
    .limit(1);

  const topCategory = topCatResult[0]?.name ?? null;

  res.json({
    month: monthStr,
    totalAmount,
    expenseCount,
    averageExpense: Math.round(averageExpense * 100) / 100,
    topCategory,
  });
});

router.get("/summary/by-category", async (req, res): Promise<void> => {
  const query = GetSummaryByCategoryQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const monthStr = query.data.month ?? new Date().toISOString().slice(0, 7);
  const [year, month] = monthStr.split("-").map(Number);
  const start = new Date(year, month - 1, 1);
  const end = new Date(year, month, 1);

  const rows = await db
    .select({
      categoryId: expensesTable.categoryId,
      categoryName: categoriesTable.name,
      categoryColor: categoriesTable.color,
      categoryIcon: categoriesTable.icon,
      totalAmount: sql<string>`sum(${expensesTable.amount})`,
      expenseCount: sql<number>`count(*)::int`,
    })
    .from(expensesTable)
    .leftJoin(categoriesTable, eq(expensesTable.categoryId, categoriesTable.id))
    .where(sql`${expensesTable.date} >= ${start.toISOString()} AND ${expensesTable.date} < ${end.toISOString()}`)
    .groupBy(expensesTable.categoryId, categoriesTable.name, categoriesTable.color, categoriesTable.icon)
    .orderBy(sql`sum(${expensesTable.amount}) desc`);

  const grandTotal = rows.reduce((acc, r) => acc + parseFloat(r.totalAmount), 0);

  const result = rows.map((r) => {
    const total = parseFloat(r.totalAmount);
    return {
      categoryId: r.categoryId,
      categoryName: r.categoryName ?? "Без категории",
      categoryColor: r.categoryColor ?? "#94a3b8",
      categoryIcon: r.categoryIcon ?? "circle",
      totalAmount: total,
      expenseCount: r.expenseCount,
      percentage: grandTotal > 0 ? Math.round((total / grandTotal) * 10000) / 100 : 0,
    };
  });

  res.json(result);
});

router.get("/summary/recent", async (req, res): Promise<void> => {
  const expenses = await db
    .select({
      id: expensesTable.id,
      amount: expensesTable.amount,
      description: expensesTable.description,
      categoryId: expensesTable.categoryId,
      categoryName: categoriesTable.name,
      categoryColor: categoriesTable.color,
      categoryIcon: categoriesTable.icon,
      date: expensesTable.date,
      createdAt: expensesTable.createdAt,
    })
    .from(expensesTable)
    .leftJoin(categoriesTable, eq(expensesTable.categoryId, categoriesTable.id))
    .orderBy(desc(expensesTable.date))
    .limit(10);

  res.json(expenses.map((e) => ({ ...e, amount: parseFloat(e.amount as unknown as string) })));
});

export default router;
