import { Router, type IRouter } from "express";
import { db, expensesTable, categoriesTable } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";
import {
  ListExpensesQueryParams,
  CreateExpenseBody,
  GetExpenseParams,
  UpdateExpenseBody,
  UpdateExpenseParams,
  DeleteExpenseParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/expenses", async (req, res): Promise<void> => {
  const query = ListExpensesQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  let dbQuery = db
    .select({
      id: expensesTable.id,
      amount: expensesTable.amount,
      description: expensesTable.description,
      categoryId: expensesTable.categoryId,
      categoryName: categoriesTable.name,
      categoryColor: categoriesTable.color,
      categoryIcon: categoriesTable.icon,
      date: expensesTable.date,
      createdAt: expensesTable.createdAt,
    })
    .from(expensesTable)
    .leftJoin(categoriesTable, eq(expensesTable.categoryId, categoriesTable.id))
    .orderBy(desc(expensesTable.date))
    .$dynamic();

  const conditions = [];

  if (query.data.categoryId != null) {
    conditions.push(eq(expensesTable.categoryId, query.data.categoryId));
  }

  if (query.data.month) {
    const [year, month] = query.data.month.split("-").map(Number);
    const start = new Date(year, month - 1, 1);
    const end = new Date(year, month, 1);
    conditions.push(sql`${expensesTable.date} >= ${start.toISOString()} AND ${expensesTable.date} < ${end.toISOString()}`);
  }

  for (const cond of conditions) {
    dbQuery = dbQuery.where(cond) as typeof dbQuery;
  }

  const expenses = await dbQuery;

  const result = expenses.map((e) => ({
    ...e,
    amount: parseFloat(e.amount as unknown as string),
  }));

  res.json(result);
});

router.post("/expenses", async (req, res): Promise<void> => {
  const parsed = CreateExpenseBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [expense] = await db
    .insert(expensesTable)
    .values({
      amount: String(parsed.data.amount),
      description: parsed.data.description,
      categoryId: parsed.data.categoryId ?? null,
      date: parsed.data.date ? new Date(parsed.data.date) : new Date(),
    })
    .returning();

  const [full] = await db
    .select({
      id: expensesTable.id,
      amount: expensesTable.amount,
      description: expensesTable.description,
      categoryId: expensesTable.categoryId,
      categoryName: categoriesTable.name,
      categoryColor: categoriesTable.color,
      categoryIcon: categoriesTable.icon,
      date: expensesTable.date,
      createdAt: expensesTable.createdAt,
    })
    .from(expensesTable)
    .leftJoin(categoriesTable, eq(expensesTable.categoryId, categoriesTable.id))
    .where(eq(expensesTable.id, expense.id));

  res.status(201).json({
    ...full,
    amount: parseFloat(full!.amount as unknown as string),
  });
});

router.get("/expenses/:id", async (req, res): Promise<void> => {
  const params = GetExpenseParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [expense] = await db
    .select({
      id: expensesTable.id,
      amount: expensesTable.amount,
      description: expensesTable.description,
      categoryId: expensesTable.categoryId,
      categoryName: categoriesTable.name,
      categoryColor: categoriesTable.color,
      categoryIcon: categoriesTable.icon,
      date: expensesTable.date,
      createdAt: expensesTable.createdAt,
    })
    .from(expensesTable)
    .leftJoin(categoriesTable, eq(expensesTable.categoryId, categoriesTable.id))
    .where(eq(expensesTable.id, params.data.id));

  if (!expense) {
    res.status(404).json({ error: "Expense not found" });
    return;
  }

  res.json({ ...expense, amount: parseFloat(expense.amount as unknown as string) });
});

router.patch("/expenses/:id", async (req, res): Promise<void> => {
  const params = UpdateExpenseParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateExpenseBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: Record<string, unknown> = {};
  if (parsed.data.amount != null) updateData.amount = String(parsed.data.amount);
  if (parsed.data.description != null) updateData.description = parsed.data.description;
  if ("categoryId" in parsed.data) updateData.categoryId = parsed.data.categoryId ?? null;
  if (parsed.data.date != null) updateData.date = new Date(parsed.data.date);

  await db
    .update(expensesTable)
    .set(updateData)
    .where(eq(expensesTable.id, params.data.id));

  const [updated] = await db
    .select({
      id: expensesTable.id,
      amount: expensesTable.amount,
      description: expensesTable.description,
      categoryId: expensesTable.categoryId,
      categoryName: categoriesTable.name,
      categoryColor: categoriesTable.color,
      categoryIcon: categoriesTable.icon,
      date: expensesTable.date,
      createdAt: expensesTable.createdAt,
    })
    .from(expensesTable)
    .leftJoin(categoriesTable, eq(expensesTable.categoryId, categoriesTable.id))
    .where(eq(expensesTable.id, params.data.id));

  if (!updated) {
    res.status(404).json({ error: "Expense not found" });
    return;
  }

  res.json({ ...updated, amount: parseFloat(updated.amount as unknown as string) });
});

router.delete("/expenses/:id", async (req, res): Promise<void> => {
  const params = DeleteExpenseParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(expensesTable)
    .where(eq(expensesTable.id, params.data.id))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Expense not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
