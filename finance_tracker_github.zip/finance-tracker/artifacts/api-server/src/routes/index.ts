import { Router, type IRouter } from "express";
import healthRouter from "./health";
import categoriesRouter from "./categories";
import expensesRouter from "./expenses";
import summaryRouter from "./summary";

const router: IRouter = Router();

router.use(healthRouter);
router.use(categoriesRouter);
router.use(expensesRouter);
router.use(summaryRouter);

export default router;
